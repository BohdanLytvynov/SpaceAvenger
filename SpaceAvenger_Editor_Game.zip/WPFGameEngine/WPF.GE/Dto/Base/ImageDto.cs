﻿namespace WPFGameEngine.WPF.GE.Dto.Base
{
    public abstract class ImageDto : ComponentDto
    {
        public string ResourceKey { get; set; }
    }
}
