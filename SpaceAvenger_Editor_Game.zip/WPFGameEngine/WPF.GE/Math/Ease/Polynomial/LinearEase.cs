﻿using WPFGameEngine.Attributes.Editor;
using WPFGameEngine.Attributes.Factories;
using WPFGameEngine.Enums;
using WPFGameEngine.WPF.GE.Math.Ease.Base;

namespace WPFGameEngine.WPF.GE.Math.Ease.Polynomial
{
    [VisibleInEditor(FactoryName = nameof(LinearEase),
        DisplayName = "Linear Ease f(t)=t", 
        GameObjectType = Enums.GEObjectType.Ease)]
    [BuildWithFactory<GEObjectType>(GameObjectType = GEObjectType.Ease)]
    public class LinearEase : EaseBase, IEase
    {
        public override double Ease(double t)
        {
            return base.Ease(t) * t;
        }
    }
}
