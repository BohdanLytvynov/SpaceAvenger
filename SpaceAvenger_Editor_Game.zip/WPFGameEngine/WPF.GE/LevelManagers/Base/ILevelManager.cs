﻿using WPFGameEngine.WPF.GE.GameObjects.Updatable;

namespace WPFGameEngine.WPF.GE.LevelManagers.Base
{
    internal interface ILevelManager : IUpdatable
    {
    }
}
