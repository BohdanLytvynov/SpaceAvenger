﻿using WPFGameEngine.Factories.Base;

namespace WPFGameEngine.Factories.Components.RelativeTransforms
{
    public interface IRelativeTransformFactory : IFactory
    {
    }
}
