﻿using WPFGameEngine.Factories.Base;

namespace WPFGameEngine.Factories.Components.Colliders
{
    public interface IColliderFactory : IFactory
    {
    }
}
