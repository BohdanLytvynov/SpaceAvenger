﻿using WPFGameEngine.Factories.Base;
using WPFGameEngine.WPF.GE.Component.Transforms;

namespace WPFGameEngine.Factories.Components.Transform
{
    public interface ITransformFactory : IFactory
    {
    }
}
