﻿using WPFGameEngine.Factories.Base;
using WPFGameEngine.WPF.GE.Component.Animators;

namespace WPFGameEngine.Factories.Components.Animators
{
    public interface IAnimatorFactory : IFactory
    {
    }
}
