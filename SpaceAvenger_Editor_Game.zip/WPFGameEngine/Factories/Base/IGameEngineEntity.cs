﻿namespace WPFGameEngine.Factories.Base
{
    public interface IGameEngineEntity
    {
    }
}
