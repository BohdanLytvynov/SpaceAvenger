﻿namespace WPFGameEngine
{
    public static class GEConstants
    {
        #region Math
        public static double Epsilon { get; set; } = 1e-12;
        #endregion
    }
}
