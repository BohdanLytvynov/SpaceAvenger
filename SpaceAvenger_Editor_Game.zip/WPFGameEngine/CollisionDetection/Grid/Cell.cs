﻿namespace WPFGameEngine.CollisionDetection.Grid
{
    public class Cell
    {

    }
}
