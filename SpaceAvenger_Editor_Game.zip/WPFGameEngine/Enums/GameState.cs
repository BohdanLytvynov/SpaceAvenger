﻿namespace WPFGameEngine.Enums
{
    public enum GameState
    {
        Running = 0,
        Paused,
        Stopped
    }
}
