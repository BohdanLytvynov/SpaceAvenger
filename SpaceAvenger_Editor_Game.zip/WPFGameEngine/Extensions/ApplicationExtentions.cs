﻿namespace WPFGameEngine.Extensions
{
    public static class ApplicationExtentions
    {
        
    }


}
