﻿using SpaceAvenger.Game.Core.Base;

namespace SpaceAvenger.Game.Core.Environment
{
    public class Asteroid1 : AsteroidBase
    {
       
    }
}
