﻿using SpaceAvenger.Game.Core.Base;

namespace SpaceAvenger.Game.Core.Animations.Explosions
{
    public class GunBlast : ExplosionBase
    {
        
    }
}
