﻿using SpaceAvenger.Game.Core.Base;

namespace SpaceAvenger.Game.Core.Factions.F10.Engines
{
    public class F10Jet : JetBase
    {
        
    }
}
