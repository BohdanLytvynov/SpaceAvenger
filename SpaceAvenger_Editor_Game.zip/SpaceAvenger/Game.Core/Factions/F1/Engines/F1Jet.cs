﻿using SpaceAvenger.Game.Core.Base;

namespace SpaceAvenger.Game.Core.Factions.F1.Engines
{
    public class F1Jet : JetBase
    {

    }
}
