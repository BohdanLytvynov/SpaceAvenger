﻿using WPFGameEngine.WPF.GE.GameObjects;

namespace SpaceAvenger.Game.Core.UI.Base
{
    public abstract class UIElementBase : MapableObject
    {
    }
}
