﻿using WPFGameEngine.WPF.GE.GameObjects;

namespace SpaceAvenger.Game.Core.Base
{
    public abstract class AsteroidBase : MapableObject
    {
    }
}
