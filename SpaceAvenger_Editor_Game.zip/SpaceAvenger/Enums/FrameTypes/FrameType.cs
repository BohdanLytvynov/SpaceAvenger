﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceAvenger.Enums.FrameTypes
{
    public enum FrameType : byte
    {
        MainFrame = 1,
        InfoFrame
    }    
}
