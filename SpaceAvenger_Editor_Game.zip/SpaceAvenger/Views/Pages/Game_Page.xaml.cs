﻿using System;
using System.Diagnostics;
using System.Windows.Controls;
using System.Windows.Input;

namespace SpaceAvenger.Views.Pages
{
    /// <summary>
    /// Interaction logic for Game_Page.xaml
    /// </summary>
    public partial class Game_Page : Page
    {
        public Game_Page()
        {
            InitializeComponent();
        }
    }
}
