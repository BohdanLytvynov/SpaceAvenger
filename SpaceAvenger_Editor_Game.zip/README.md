## Space Avenger Game

[![SonarCloud](https://sonarcloud.io/images/project_badges/sonarcloud-white.svg)](https://sonarcloud.io/summary/new_code?id=BohdanLytvynov_SpaceAvenger_Game)

[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=BohdanLytvynov_SpaceAvenger_Game&metric=alert_status)](https://sonarcloud.io/summary/new_code?id=BohdanLytvynov_SpaceAvenger_Game) [![Bugs](https://sonarcloud.io/api/project_badges/measure?project=BohdanLytvynov_SpaceAvenger_Game&metric=bugs)](https://sonarcloud.io/summary/new_code?id=BohdanLytvynov_SpaceAvenger_Game) [![Code Smells](https://sonarcloud.io/api/project_badges/measure?project=BohdanLytvynov_SpaceAvenger_Game&metric=code_smells)](https://sonarcloud.io/summary/new_code?id=BohdanLytvynov_SpaceAvenger_Game) [![Coverage](https://sonarcloud.io/api/project_badges/measure?project=BohdanLytvynov_SpaceAvenger_Game&metric=coverage)](https://sonarcloud.io/summary/new_code?id=BohdanLytvynov_SpaceAvenger_Game) [![Duplicated Lines (%)](https://sonarcloud.io/api/project_badges/measure?project=BohdanLytvynov_SpaceAvenger_Game&metric=duplicated_lines_density)](https://sonarcloud.io/summary/new_code?id=BohdanLytvynov_SpaceAvenger_Game)

#### Unit Tests Results

[![.NET Core Desktop Auto Unit Test Runner](https://github.com/BohdanLytvynov/SpaceAvenger_Game/actions/workflows/dotnet-desktop-unit-testing.yml/badge.svg)](https://github.com/BohdanLytvynov/SpaceAvenger_Game/actions/workflows/dotnet-desktop-unit-testing.yml)
