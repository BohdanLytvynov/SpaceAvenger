﻿using System.Windows;

namespace SpaceAvenger.Editor.Views
{
    /// <summary>
    /// Interaction logic for AnimationConfigurationWindow.xaml
    /// </summary>
    public partial class AnimationConfigurationWindow : Window
    {
        public AnimationConfigurationWindow()
        {
            InitializeComponent();
        }
    }
}
