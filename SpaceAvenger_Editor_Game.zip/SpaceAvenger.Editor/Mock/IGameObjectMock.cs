﻿using WPFGameEngine.WPF.GE.GameObjects;
using WPFGameEngine.WPF.GE.GameObjects.Collidable;

namespace SpaceAvenger.Editor.Mock
{
    internal interface IGameObjectMock : IExportable, ICollidable, ICloneable
    {
    }
}
