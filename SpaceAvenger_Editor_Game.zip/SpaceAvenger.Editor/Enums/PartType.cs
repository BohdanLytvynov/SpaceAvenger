﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceAvenger.Editor.Enums
{
    internal enum PartType
    {
        None = 0,
        Corpus,
        Engines,
        Weapons
    }
}
