﻿using SpaceAvenger.Editor.Mock;
using SpaceAvenger.Editor.ViewModels.TreeItems;
using System.Collections.ObjectModel;
using System.Windows.Input;
using ViewModelBaseLibDotNetCore.Commands;
using ViewModelBaseLibDotNetCore.VM;
using WPFGameEngine.WPF.GE.Component.Sprites;
using WPFGameEngine.WPF.GE.Component.Transforms;
using WPFGameEngine.WPF.GE.GameObjects;
using WPFGameEngine.WPF.GE.Settings;
using SpaceAvenger.Editor.ViewModels.Components.Base;
using WPFGameEngine.Attributes.Editor;
using WPFGameEngine.WPF.GE.Component.Base;
using WPFGameEngine.WPF.GE.Exceptions;
using WPFGameEngine.Timers.Base;
using WPFGameEngine.Extensions;
using SpaceAvenger.Editor.ViewModels.Options;
using WPFGameEngine.Enums;
using WPFGameEngine.Services.Interfaces;
using WPFGameEngine.FactoryWrapper.Base;
using Microsoft.Win32;
using ViewModelBaseLibDotNetCore.Helpers;
using WPFGameEngine.WPF.GE.Serialization.GameObjects;
using WPFGameEngine.WPF.GE.Component.RelativeTransforms;
using System.Numerics;
using SpaceAvenger.Editor.ViewModels.Prefabs;
using WPFGameEngine.WPF.GE.Dto.GameObjects;
using SpaceAvenger.Services.WpfGameViewHost;
using System.Windows;
using System.IO;
using ViewModelBaseLibDotNetCore.MessageBus.Base;
using SpaceAvenger.Editor.MessageBus;
using Microsoft.Extensions.DependencyInjection;
using SpaceAvenger.Editor.Views;
using SpaceAvenger.Editor.ViewModels.Helpers;

namespace SpaceAvenger.Editor.ViewModels
{
    internal class EditorMainWindowViewModel : SubscriptableViewModel
    {
        #region Fields
        private string m_title;
        private WpfGameObjectViewHost m_gameViewHost;
        private TreeItemViewModel? m_SelectedItem;

        private bool m_ShowGizmos;
        private bool m_ShowBorders;
        private bool m_enabled;
        private bool m_showColliders;
        private string m_objName;
        private string m_UniqueName;
        private double m_ZIndex;
        private int m_SelectedComponentIndex;
        private OptionsViewModel m_SelectedComponent;
        private PrefabViewModel m_SelectedPrefab;
        private ObservableCollection<TreeItemViewModel> m_Items;
        private ObservableCollection<ComponentViewModel> m_Components;
        private ObservableCollection<OptionsViewModel> m_ComponentsToAdd;
        private ObservableCollection<PrefabViewModel> m_prefabs;
        private List<GameObjectDto> m_Dtos;
        private IAssemblyLoader m_assemblyLoader;
        private IFactoryWrapper m_factoryWrapper;
        private IGameTimer m_gameTimer;
        private IGameObjectExporter m_gameObjectExporter;
        private IGameObjectImporter m_gameObjectImporter;
        private IMessageBus m_MessageBus;
        private IServiceProvider m_serviceProvider;
        private string m_pathToExport;

        #endregion

        #region Properties
        public string PathToExport 
        { get => m_pathToExport; set => Set(ref m_pathToExport, value); }

        public string Title
        { get => m_title; set => Set(ref m_title, value); }

        public OptionsViewModel SelectedComponent
        {
            get => m_SelectedComponent;
            set => Set(ref m_SelectedComponent, value);
        }

        public int SelectedComponentIndex
        {
            get => m_SelectedComponentIndex;
            set => Set(ref m_SelectedComponentIndex, value);
        }

        public double ZIndex
        {
            get => m_ZIndex;
            set
            {
                Set(ref m_ZIndex, value);
                UpdateZIndex((int)ZIndex);
            }
        }

        public bool Enabled
        {
            get => m_enabled;
            set
            {
                Set(ref m_enabled, value);
                UpdateEnabled(value);
            }
        }

        public string ObjName
        {
            get => m_objName;
            set => Set(ref m_objName, value);
        }

        public string UniqueName 
        { 
            get => m_UniqueName;
            set => Set(ref m_UniqueName, value);
        }

        public ObservableCollection<TreeItemViewModel> Items
        {
            get => m_Items;
            set => m_Items = value;
        }

        public ObservableCollection<ComponentViewModel> Components
        {
            get => m_Components;
            set => m_Components = value;
        }

        public ObservableCollection<OptionsViewModel> ComponentsToAdd
        {
            get => m_ComponentsToAdd;
            set => m_ComponentsToAdd = value;
        }

        public ObservableCollection<PrefabViewModel> Prefabs 
        {
            get => m_prefabs;
            set => m_prefabs = value;
        }
        public bool ShowGizmos
        {
            get => m_ShowGizmos;
            set
            {
                Set(ref m_ShowGizmos, value);
                GESettings.DrawGizmo = value;
            }
        }

        public bool ShowBorders
        {
            get => m_ShowBorders;
            set
            {
                Set(ref m_ShowBorders, value);
                GESettings.DrawBorders = value;
            }
        }

        public bool ShowColliders 
        { 
            get => m_showColliders;
            set
            {
                Set(ref m_showColliders, value);
                GESettings.DrawColliders = value;
            }
        }

        public WpfGameObjectViewHost GameView
        { get => m_gameViewHost; set => Set(ref m_gameViewHost, value); }

        public PrefabViewModel SelectedPrefab 
        { get => m_SelectedPrefab; set => Set(ref m_SelectedPrefab, value); }
        #endregion

        #region Commands
        public ICommand OnAddGameObjectButtonPressed { get; }

        public ICommand OnDeleteGameObjectButtonPressed { get; }

        public ICommand OnAddComponentButtonPressed { get; }

        public ICommand OnDeleteComponentButtonPressed { get; }

        public ICommand OnExportButtonPressed { get; }

        public ICommand OnOpenDialogButtonPressed { get; }

        public ICommand OnRefreshPrefabsButtonPressed { get; }

        public ICommand OnLoadPrefabButtonPressed { get; }

        public ICommand OnRemovePrefabButtonPressed { get; }

        public ICommand OnCopyGameObjectButtonPressed { get; }

        public ICommand OnCopyComponentButtonPressed { get; }

        public ICommand OnOpenBufferButtonPressed { get; }
        #endregion

        #region IData Error Info
        public override string this[string columnName]
        {
            get 
            {
                string error = string.Empty;

                switch (columnName)
                {
                    case nameof(PathToExport):
                        SetValidArrayValue(0, !ValidationHelper.TextIsEmpty(PathToExport, out error));
                        break;
                }

                return error;
            }
        }
        #endregion

        #region Ctor
        public EditorMainWindowViewModel(
            IFactoryWrapper factoryWrapper,
            IGameTimer gameTimer,
            IAssemblyLoader assemblyLoader,
            IGameObjectExporter gameObjectExporter,
            IGameObjectImporter gameObjectImporter,
            IMessageBus messageBus,
            IServiceProvider serviceProvider) : this()
        {
            m_factoryWrapper = factoryWrapper ?? throw new ArgumentNullException(nameof(factoryWrapper));
            m_assemblyLoader = assemblyLoader ?? throw new ArgumentNullException(nameof(assemblyLoader));
            m_gameObjectExporter = gameObjectExporter ?? throw new ArgumentNullException(nameof(gameObjectExporter));
            m_gameObjectImporter = gameObjectImporter ?? throw new ArgumentNullException(nameof(gameObjectImporter));
            m_MessageBus = messageBus ?? throw new ArgumentNullException(nameof(messageBus));
            m_SelectedComponent = new OptionsViewModel();
            m_serviceProvider = serviceProvider ?? throw new ArgumentNullException(nameof(serviceProvider));

            m_Dtos = new List<GameObjectDto>();

            #region Get All Components From GE
            m_ComponentsToAdd = new ObservableCollection<OptionsViewModel>();
            var geAssembly = m_assemblyLoader["WPFGameEngine"];

            foreach (var type in geAssembly.GetTypes())
            {
                var attr = type.GetAttribute<VisibleInEditor>();
                if (attr != null && attr.GetValue<GEObjectType>("GameObjectType") == GEObjectType.Component)
                {
                    m_ComponentsToAdd.Add(new OptionsViewModel(
                        attr.GetValue<string>("DisplayName"),
                        attr.GetValue<string>("FactoryName")));
                }
            }

            #endregion

            m_gameTimer = gameTimer ?? throw new ArgumentNullException(nameof(gameTimer));
            m_gameViewHost = new WpfGameObjectViewHost(m_gameTimer);
            m_gameViewHost.StartGame();

            Subscriptions.Add(m_MessageBus.
                RegisterHandler<PasteFromGameObjectBufferMessage, IGameObjectMock>
                (OnPasteGameObjectFromBuffer));

            Subscriptions.Add(m_MessageBus
                .RegisterHandler<PasteFromComponentsBufferMessage, IGEComponent>
                (OnPasteComponentFromBuffer));
        }

        public EditorMainWindowViewModel()
        {
            InitValidArray(1);
            m_title = "Game Editor";
            m_ShowBorders = true;
            m_ShowGizmos = true;
            m_showColliders = true;
            m_SelectedItem = null;
            m_Items = new ObservableCollection<TreeItemViewModel>();
            m_Components = new ObservableCollection<ComponentViewModel>();
            m_prefabs = new ObservableCollection<PrefabViewModel>();
            m_objName = string.Empty;
            m_UniqueName = string.Empty;
            m_SelectedComponentIndex = -1;
            m_SelectedComponent = new OptionsViewModel();
            m_pathToExport = string.Empty;
            m_SelectedPrefab = new PrefabViewModel();

            GESettings.DrawGizmo = true;
            GESettings.DrawBorders = true;
            GESettings.DrawColliders = true;

            OnAddGameObjectButtonPressed = new Command(
                OnAddGameObjectButtonPressedExecute,
                CanOnAddGameObjectButtonPressedExecute
                );

            OnDeleteGameObjectButtonPressed = new Command(
                OnDeleteObjectButtonPressedExecute,
                CanOnDeleteObjectButtonPressedExecute
                );

            OnAddComponentButtonPressed = new Command(
                OnAddComponentButtonPressedExecute,
                CanOnAddComponentButtonPressedExecute
                );

            OnDeleteComponentButtonPressed = new Command(
                OnDeleteComponentButtonPressedExecute,
                CanOnDeleteComponentButtonPressedExecute);

            OnExportButtonPressed = new Command(
                OnExportButtonPressedExecute,
                CanOnExportButtonPressedExecute);

            OnOpenDialogButtonPressed = new Command(
                OnOpenDialogButtonPressedExecute,
                CanOnOpenDialogButtonPressedExecute);

            OnRefreshPrefabsButtonPressed = new Command(
                OnRefreshPrefabsButtonPressedExecute,
                CanOnRefreshPrefabsButtonPressedExecute);

            OnLoadPrefabButtonPressed = new Command(
                OnLoadPrefabButtonPressedExecute,
                CanOnLoadPrefabButtonPressedExecute);

            OnRemovePrefabButtonPressed = new Command(
                OnRemovePrefabButtonPressedExecute,
                CanOnRemovePrefabButtonPressedExecute);

            OnCopyGameObjectButtonPressed = new Command
                (
                    OnCopyObjectButtonPressedExecute, 
                    CanOnCopyObjectButtonPressedExecute);

            OnCopyComponentButtonPressed = new Command
                (
                    OnCopyComponentButtonPressedExecute,
                    CanOnCopyComponentButtonPressedExecute
                );

            OnOpenBufferButtonPressed = new Command(
                OnOpenBufferButtonPressedExecute,
                CanOnOpenBufferButtonPressedExecute);
        }

        #endregion 

        #region Methods

        private void OnPasteComponentFromBuffer(PasteFromComponentsBufferMessage msg)
        {
            if (msg == null) return;
            var content = msg.Content;
            if(content == null) return;
            if (m_SelectedItem == null)
            {
                MessageBox.Show("No Game Object was selected!",
                    m_title, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }

            try
            {
                m_SelectedItem.GameObject.RegisterComponent(content);

                Components.Add(ComponentViewModelHelper.CreateComponentViewModel(
                    content,
                    m_SelectedItem.GameObject,
                    m_factoryWrapper, m_assemblyLoader));
            }
            catch (IncompatibleComponentException ex)
            {
                MessageBox.Show(ex.Message, m_title, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
            catch (ComponentAlreadyRegisteredException ex)
            {
                MessageBox.Show(ex.Message, m_title, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void OnPasteGameObjectFromBuffer(PasteFromGameObjectBufferMessage msg)
        {
            var content = msg.Content;
            if (content == null) return;

            if (content.GameTimer == null && content.GameView == null)
                content.StartUp(GameView, m_gameTimer);

            if (m_SelectedItem == null)
            {
                TreeItemViewModel itemViewModel = new(Items.Count + 1, content);
                itemViewModel.ItemSelected += ItemViewModel_ItemSelected;
                Items.Add(itemViewModel);
                m_gameViewHost.AddObject(content);
            }
            else
            {
                TreeItemViewModel itemViewModel = new(m_SelectedItem.Children.Count + 1, content);
                itemViewModel.ItemSelected += ItemViewModel_ItemSelected;
                m_SelectedItem.Children.Add(itemViewModel);
                var transform = content.GetComponent<TransformComponent>(false);
                if (transform != null)
                { 
                    var relTransform = m_factoryWrapper.CreateObject<RelativeTransformComponent>();
                    relTransform.Scale = transform.Scale;
                    relTransform.CenterPosition = transform.CenterPosition;
                    content.UnregisterComponent(transform);
                    content.RegisterComponent(relTransform);
                }
                m_SelectedItem.GameObject.AddChild(content);
            }
        }

        private void RefreshPrefabs()
        {
            Prefabs.Clear();
            m_Dtos.Clear();
            m_gameObjectImporter.PathToFolder = PathToExport;
            foreach (var item in m_gameObjectImporter.ImportObjects())
            {
                Prefabs.Add(new PrefabViewModel(Prefabs.Count + 1) { PrefabName = item.ObjectName });
                m_Dtos.Add(item);
            }

            m_SelectedPrefab = new PrefabViewModel();
        }

        private TreeItemViewModel LoadObjectToTree(IGameObjectMock gameObject, int count = 1)
        {
            if (gameObject == null)
                return null;

            TreeItemViewModel treeItem = new TreeItemViewModel(count, gameObject);
            treeItem.ItemSelected += ItemViewModel_ItemSelected;
            foreach (var item in gameObject.Children)
            {
                var ch = LoadObjectToTree((IGameObjectMock)item, count);
                treeItem.Children.Add(ch);
                count++;
            }

            return treeItem;
        }

        private IGameObjectMock LoadPrefabGameObjectRec(GameObjectDto dto)
        {
            if (dto == null)
                return null;

            IGameObjectMock prefab = new GameObjectMock();
            prefab.Enabled = dto.Enabled;
            prefab.ZIndex = dto.ZIndex;
            prefab.ObjectName = dto.ObjectName;
            prefab.UniqueName = dto.UniqueName;

            foreach (var c in dto.Components)
            {
                prefab.RegisterComponent(c.ToObject(m_factoryWrapper));
            }

            foreach (var ch in dto.Children)
            {
                var child = LoadPrefabGameObjectRec(ch);
                prefab.AddChild(child);
            }

            return prefab;
        }

        private void ItemViewModel_ItemSelected(int id)
        {
            m_SelectedItem = null;

            if (id >= 0)
            {
                TreeItemViewModel.FindInCollection(id, Items, ref m_SelectedItem);

                TreeItemViewModel.UnselectAll(Items);
                m_SelectedItem.RaiseEvent = false;
                m_SelectedItem.Selected = true;
                m_SelectedItem.RaiseEvent = true;
                UpdateGameObjectProperties();
                UpdateComponents();
            }
            else
            {
                Components.Clear();
                TreeItemViewModel.UnselectAll(Items);
            }
        }

        #region On Add Object Button Pressed
        private bool CanOnAddGameObjectButtonPressedExecute(object p) => true;

        private void OnAddGameObjectButtonPressedExecute(object p)
        {
            IGameObjectMock obj = new GameObjectMock();

            if (m_SelectedItem == null)
            {
                TreeItemViewModel itemViewModel = new(Items.Count + 1, obj);
                itemViewModel.ItemSelected += ItemViewModel_ItemSelected;
                Items.Add(itemViewModel);
                var t = m_factoryWrapper.CreateObject<TransformComponent>();
                t.Scale = new WPFGameEngine.WPF.GE.Math.Sizes.Size(1f, 1f);
                t.CenterPosition = new Vector2(0.5f, 0.5f);
                obj.RegisterComponent(t);
                m_gameViewHost.AddObject(obj);
            }
            else
            {
                TreeItemViewModel itemViewModel = new(m_SelectedItem.Children.Count + 1, obj);
                itemViewModel.ItemSelected += ItemViewModel_ItemSelected;
                m_SelectedItem.Children.Add(itemViewModel);
                var t = m_factoryWrapper.CreateObject<RelativeTransformComponent>();
                t.Scale = new WPFGameEngine.WPF.GE.Math.Sizes.Size(1f, 1f);
                t.CenterPosition = new Vector2(0.5f, 0.5f);
                obj.RegisterComponent(t);
                obj.StartUp(m_gameViewHost, m_gameTimer);
                m_SelectedItem.GameObject.AddChild(obj);
            }

            var sprite = m_factoryWrapper.CreateObject<Sprite>();
            sprite.Load("Empty");
            obj.RegisterComponent(sprite);
        }

        #endregion

        #region On Open Buffer Button Pressed

        private bool CanOnOpenBufferButtonPressedExecute(object p) => true;

        private void OnOpenBufferButtonPressedExecute(object p)
        {
            var buffWindow = m_serviceProvider.GetRequiredService<BufferWindowView>();
            buffWindow.Topmost = true;
            buffWindow.Show();
        }

        #endregion

        #region On Copy Object Button Pressed

        private bool CanOnCopyObjectButtonPressedExecute(object p) => m_SelectedItem != null && m_SelectedItem.ShowNumber >= 0;

        private void OnCopyObjectButtonPressedExecute(object p)
        {
            m_MessageBus.Send<CopyToGameObjectBufferMessage, TreeItemViewModel>(
                new CopyToGameObjectBufferMessage((TreeItemViewModel)m_SelectedItem.Clone()));
        }

        #endregion

        #region On Copy Component Button Pressed

        private bool CanOnCopyComponentButtonPressedExecute(object p) => SelectedComponentIndex >= 0;

        private void OnCopyComponentButtonPressedExecute(object p)
        {
            m_MessageBus.Send<CopyToComponentsBufferMessage, ComponentViewModel>
                (new CopyToComponentsBufferMessage(Components[SelectedComponentIndex]));
        }

        #endregion

        #region On Delete Object ButtonPressed

        private bool CanOnDeleteObjectButtonPressedExecute(object p) => m_SelectedItem != null;

        private void OnDeleteObjectButtonPressedExecute(object p)
        {
            if (m_SelectedItem != null)
            {
                var components = m_SelectedItem.GameObject.GetComponents();

                foreach (var c in components)
                {
                    m_SelectedItem.GameObject.UnregisterComponent(c);
                }

                RemoveFromWorld(m_SelectedItem.GameObject);

                m_SelectedItem.ItemSelected -= ItemViewModel_ItemSelected;
                RemoveObjectFromTreeRec(m_SelectedItem, Items, false);
                Components.Clear();
                m_SelectedItem = null;
            }

        }

        #endregion

        #region On Add Component Button Pressed
        private bool CanOnAddComponentButtonPressedExecute(object p) =>
            m_SelectedItem != null && SelectedComponent != null 
            && !string.IsNullOrEmpty(SelectedComponent.FactoryName);

        private void OnAddComponentButtonPressedExecute(object p)
        {
            try
            {
                var component = (IGEComponent)m_factoryWrapper.CreateObject(SelectedComponent.FactoryName);
                m_SelectedItem.GameObject.RegisterComponent(component);

                Components.Add(ComponentViewModelHelper.CreateComponentViewModel(component,
                    m_SelectedItem.GameObject,
                    m_factoryWrapper, m_assemblyLoader));
            }
            catch (IncompatibleComponentException ex)
            {
                MessageBox.Show(ex.Message, m_title, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
            catch (ComponentAlreadyRegisteredException ex)
            {
                MessageBox.Show(ex.Message, m_title, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region On Delete Component Button Pressed

        private bool CanOnDeleteComponentButtonPressedExecute(object p) =>
            m_SelectedItem != null && SelectedComponentIndex >= 0;

        private void OnDeleteComponentButtonPressedExecute(object p)
        {
            var componentViewModel = Components[SelectedComponentIndex];
            componentViewModel.GameObject.UnregisterComponent(componentViewModel.ComponentName);
            Components.RemoveAt(SelectedComponentIndex);
            SelectedComponentIndex = -1;
        }

        #endregion

        #region On Export Button Pressed Execute
        private bool CanOnExportButtonPressedExecute(object p) => Items.Count > 0 && GetValidArrayValue(0);

        private void OnExportButtonPressedExecute(object p)
        {
            int count = 0;
            Exception ex = null;
            foreach (var item in GameView.World)
            {
                if ((item as IExportable)?.IsExported ?? false)
                {
                    m_gameObjectExporter.Export(item, PathToExport, ex);
                    count++;
                }

                if (ex != null)
                    break;
            }

            if(count == 0)
                return;

            if (ex == null)
                MessageBox.Show("Export successful!", Title, MessageBoxButton.OK, MessageBoxImage.Information);
            else
                MessageBox.Show($"Export failed! Error: {ex.Message}", Title, MessageBoxButton.OK, MessageBoxImage.Error);
        }
        #endregion

        #region On Open Dialog Button Pressed
        private bool CanOnOpenDialogButtonPressedExecute(object p) => true;

        private void OnOpenDialogButtonPressedExecute(object p)
        {
            OpenFolderDialog dialog = new OpenFolderDialog();
            if (!string.IsNullOrEmpty(PathToExport))
            { 
                dialog.DefaultDirectory = PathToExport;
            }
            if (dialog.ShowDialog() ?? false)
            { 
                PathToExport = dialog.FolderName;
            }
        }
        #endregion

        #region On Refresh Prefabs Button Pressed
        private bool CanOnRefreshPrefabsButtonPressedExecute(object p) =>
            !string.IsNullOrEmpty(PathToExport);

        private void OnRefreshPrefabsButtonPressedExecute(object p)
        {
            RefreshPrefabs();
        }
        #endregion

        #region On Load Prefab Button Pressed
        private bool CanOnLoadPrefabButtonPressedExecute(object p) =>
            SelectedPrefab != null && SelectedPrefab.ShowNumber > 0;

        private void OnLoadPrefabButtonPressedExecute(object p)
        {
            GameView.ClearWorld();
            Items.Clear();
            if (SelectedPrefab != null)
            {
                var dto = m_Dtos
                    .Where(d => d.ObjectName.Equals(SelectedPrefab.PrefabName))
                    .FirstOrDefault();

                if (dto != null)
                {
                    IGameObjectMock obj = LoadPrefabGameObjectRec(dto);
                    GameView.AddObject(obj);
                    var treeItem = LoadObjectToTree(obj);
                    Items.Add(treeItem);
                }
                else
                {
                    MessageBox.Show($"Prefab <{SelectedPrefab.PrefabName}> was not found!",
                        Title, MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        #endregion

        #region On Remove Prefab Button Pressed
        private bool CanOnRemovePrefabButtonPressedExecute(object p) =>
            SelectedPrefab != null && SelectedPrefab.ShowNumber > 0;

        private void OnRemovePrefabButtonPressedExecute(object p)
        {
            GameObject.RemoveObject(obj => obj.ObjectName.Equals(SelectedPrefab.PrefabName), 
                GameView.World, true);
            File.Delete(PathToExport + Path.DirectorySeparatorChar + SelectedPrefab.PrefabName + ".json");
            Prefabs.Remove(SelectedPrefab);
            m_SelectedPrefab = new PrefabViewModel();
        }
        #endregion

        private void RemoveObjectFromTreeRec(TreeItemViewModel item, ObservableCollection<TreeItemViewModel> src, bool removed)
        {
            if (removed)
                return;

            foreach (TreeItemViewModel itemViewModel in src)
            {
                if (removed)
                    break;

                if (itemViewModel.Id == item.Id)
                {
                    itemViewModel.ItemSelected -= ItemViewModel_ItemSelected;
                    src.Remove(itemViewModel);
                    removed = true;
                    break;
                }

                RemoveObjectFromTreeRec(item, itemViewModel.Children, removed);
            }
        }

        private void UpdateGameObjectProperties()
        {
            if (m_SelectedItem == null && m_SelectedItem.GameObject == null)
                return;

            Enabled = m_SelectedItem.GameObject.Enabled;
            ObjName = m_SelectedItem.GameObject.ObjectName;
            UniqueName = m_SelectedItem.GameObject.UniqueName;
            ZIndex = m_SelectedItem.GameObject.ZIndex;
        }

        private void UpdateComponents()
        {
            if (m_SelectedItem == null && m_SelectedItem.GameObject == null)
                return;

            Components.Clear();
            var currentComponents = m_SelectedItem?.GameObject?.GetComponents() ?? null;

            if (currentComponents == null)
                return;

            foreach (var component in currentComponents)
            {
                Components.Add(ComponentViewModelHelper.CreateComponentViewModel(component, 
                    m_SelectedItem.GameObject,
                    m_factoryWrapper, m_assemblyLoader));
            }
        }

        private void RemoveFromWorld(IGameObjectMock item)
        {
            m_gameViewHost.RemoveObject(item);
        }

        private void UpdateEnabled(bool value)
        {
            if (m_SelectedItem != null && m_SelectedItem.GameObject != null)
            {
                m_SelectedItem.GameObject.Enabled = value;
            }
        }

        private void UpdateZIndex(int value)
        {
            if (m_SelectedItem != null && m_SelectedItem.GameObject != null)
            {
                m_SelectedItem.GameObject.ZIndex = value;
            }
        }
        #endregion
    }
}
